Bike Sharing Demand  
https://www.kaggle.com/c/bike-sharing-demand/data  

For this lab, you would need to download train.csv and test.csv from kaggle.  
1. Go to the URL: https://www.kaggle.com/c/bike-sharing-demand/data  
2. Sign-in
3. Scroll down to Data Sources and download the three files (train.csv, test.csv, sampleSubmission.csv)

