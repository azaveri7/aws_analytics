Movie Example Dataset:  
For this lab, we will use movielens data from this website (data preparation script automatically downloads from this location):  
http://files.grouplens.org/datasets/movielens/ml-latest-small.zip  
