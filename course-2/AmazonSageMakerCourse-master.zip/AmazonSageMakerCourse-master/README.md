# AWS Certified Machine Learning Specialty (MLS-C01) Course
  
## To Enroll
https://www.udemy.com/course/aws-machine-learning-a-complete-guide-with-python/?referralCode=9ADB4395937F7D656EB9  
  
## What you will learn
Hi and Welcome to the AWS Certified Machine Learning Specialty (MLS-C01) Course  
  
I am Chandra Lingam, and I am your instructor.  
  
Here is what you will learn in this course:  
•	Gain first-hand experience on how to train, optimize, deploy, and integrate ML in AWS cloud  
•	AWS Built-in algorithms, Bring Your Own, Ready-to-use AI capabilities   
•	Complete Guide to AWS Certified Machine Learning – Specialty  
•	Includes a high-quality Timed practice test  (a lot of courses charge a separate fee for practice test)  
•	How to integrate the trained models in your application  
  
You will get prompt support through the course Q&A forum and private messaging  

I am looking forward to meeting you  

## To Enroll
https://www.udemy.com/course/aws-machine-learning-a-complete-guide-with-python/?referralCode=9ADB4395937F7D656EB9  
